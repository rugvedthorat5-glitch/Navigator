# Smart Campus Guide Navigator

A simple C command-line program that calculates the distance, estimated travel time, and travel recommendations between locations on a campus.

## Features

- Choose a starting location and destination from 3 predefined campus points:
  - Main Gate (0, 0)
  - Library (4, 3)
  - Computer Lab (8, 6)
- Choose a mode of transport: Walking (5 km/h) or Biking (15 km/h)
- Account for rainy weather (reduces speed by 30%)
- Calculates straight-line distance using the distance formula
- Estimates travel time in minutes
- Gives a smart safety/travel recommendation based on weather and transport mode

## Requirements

- A C compiler (e.g. `gcc`)
- Math library (`libm`, included with standard C toolchains)

## Build

```bash
gcc campus_navigator.c -o campus_navigator -lm
```

## Run

```bash
./campus_navigator
```

## Example

```
===========================================
        SMART CAMPUS GUIDE NAVIGATOR
===========================================
Available Locations:
1. Main Gate     (0, 0)
2. Library       (4, 3)
3. Computer Lab  (8, 6)
-------------------------------------------
Enter your CURRENT location (1-3): 1
Enter your DESTINATION (1-3): 3

Choose Mode of Transport:
1. Walking (5 km/h)
2. Biking (15 km/h)
Select (1-2): 2
Is it raining? (1 for Yes / 0 for No): 0

===========================================
              NAVIGATION ROUTE
===========================================
Total Distance : 10.00 km
Estimated Time : 40.0 minutes
-------------------------------------------
Smart Recommendation: Weather conditions are ideal. Have a safe journey!
===========================================
```

## License

MIT
